<?php
include("cabecalho.php");
?>

<div class="container_cadastro">
<center><h1 class="Titulo_cadastro_discente">Cadastro Externo<h1></center>
  <form action="#" class="form-contact" method="post" tabindex="1">

    <input type="text" class="form-contact-input" name="nome" placeholder="Nome Completo" required />

   

    <input type="email" class="form-contact-input" name="email" placeholder="E-mail" required />

    <input type="Number" class="form-contact-input" name="nome_resp" placeholder="CPF" />

     <textarea class="form-contact-textarea" name="conteudo" placeholder="Justificativa" required></textarea>

     

    

    <button type="submit" class="form-contact botao_cadastro">Enviar</button>

  </form>
</div>