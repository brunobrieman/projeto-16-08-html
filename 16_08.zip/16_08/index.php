<?php
 include('cabecalho.php');
?>


<div class=page>
  <style type="text/css">
    .page{
    background-image: url("./img/fundo_home.jpg");
    background-size:100%;
    background-repeat: no-repeat;

    height: 100%;
    bottom: 0;
    color: black;
    left: 0;
    float: left;


    overflow: auto;
    padding: 17em;
    
    right: 0;
    text-align: center;
    top: 0;
    width: auto;
    height: auto;
}

.card_home1{
  width: 18rem;
  float: left;
 margin-left: 4%;
  

}
.card_home2{
  width: 18rem;
  float: left;
  margin-left: 4%;
  


}
.card_home3{
  width: 18rem;
  float: left;
margin-left: 4%;
  


}
.cards_home{
  width: 140%;
  height: 10%;
  margin-top: 80%;
  margin-left: -20%;
float:left;
}


  </style>

      
        <center>
         <h1 class="animated fadeInLeftBig tituloIndex">Controle de acesso IFC</h1>
                <button type="button" class="btn btn-outline-dark my-2 my-sm-">Cadastre-se</button>
                 <button type="button" class="btn btn-outline-dark my-2 my-sm-">Entrar</button>
               
              <br>

<center><section class="cards_home">
   <div class="card_home1" >
  <img src="./img/primeiro_card.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">aqui vamos falar os beneficios do nosso sistema.</p>
  </div>
</div>
 <div class="card_home2">
  <img src="./img/fundo_home.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">aqui vamos falar os beneficios do nosso sistema.</p>
  </div>
</div>
<div class="card_home3">
  <img src="./img/fundo_home.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">aqui vamos falar os beneficios do nosso sistema.</p>
  </div>
</div>
</section>

              
  <div>
    </center>



</body>
</html>

